package yeah.fx2;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;


public class HelloController {

    @FXML
    public Rectangle kwadrat;

    @FXML
    public Rectangle kwadrat1;

    @FXML
    public Rectangle kwadrat2;

    @FXML
    public Separator sep;

    @FXML
    public Text TEXT;

    public void wypisz(String text){
        TEXT.setText(TEXT.getText()+text+"\n");
    }

    @FXML
    public Button START;

    public void start(){
        new Thread(() -> {
            try {
                ElevatorSystem.run();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }).start();
    }

    @FXML
    public Button EXIT;

    public void exit(){
        System.exit(0);
    }

    @FXML
    public Button button1;

    int lPieter;
    int lPasazerow;

    public void ustawPietra(){
        getpietra();
        ElevatorSystem.NUM_FLOORS = lPieter;
        ElevatorAnimation.ustawKondygnacje();
    }

    @FXML
    public Button button2;

    public void ustawPasazerow(){
        getpasazerzy();
        ElevatorSystem.NUM_PASSENGERS = lPasazerow;
    }

    @FXML
    public TextField pietra;

    public void getpietra(){
        lPieter = Integer.parseInt(pietra.getText());
    }

    @FXML
    public TextField pasazerzy;

    public void getpasazerzy(){
        lPasazerow = Integer.parseInt(pasazerzy.getText());
    }

    @FXML
    public ImageView bartek;

    @FXML
    public Text textFloor;

    @FXML
    public VBox KOLUMNATEXT;

    @FXML
    public VBox pasazerowiekolumna;


}