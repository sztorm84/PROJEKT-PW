package yeah.fx2;

import javafx.application.Platform;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import static java.lang.Thread.sleep;
import static yeah.fx2.ElevatorAnimation.controller;

public class ElevatorSystem {
    public static int NUM_FLOORS = 10; // Default number of floors
    private static final int NUM_ELEVATORS = 3;
    public static int NUM_PASSENGERS = 10;
    public static int MAX_CAPACITY = 5;
    final private static Elevator[] elevators = new Elevator[NUM_ELEVATORS];
    private static final AtomicInteger passengerIdCounter = new AtomicInteger(1);
    private static final Set<Passenger> allPassengers = new HashSet<>();
    private static volatile boolean running = true; // Kontrolna flaga

    public static void setNumFloors(int numFloors) {
        ElevatorSystem.NUM_FLOORS = numFloors;
    }

    public static void setNumPassengers(int numPassengers) {
        ElevatorSystem.NUM_PASSENGERS = numPassengers;
    }

    public static void main(String[] args) {
        run();
    }

    public static void run(){
        initializeSystem();

        // Add passengers for the simulation
        for (int i = 0; i < NUM_PASSENGERS; i++) {
            addRandomPassenger();
        }

        // Run the simulation
        simulate();

        // Zakończenie symulacji
        running = false;

        // Ensure all elevators complete their tasks
        for (Elevator elevator : elevators) {
            elevator.stopElevator();
        }
    }

    private static void initializeSystem() {
        elevators[0] = new W1(MAX_CAPACITY);
        elevators[1] = new W2(MAX_CAPACITY);
        elevators[2] = new W3(MAX_CAPACITY);
    }

    private static void addRandomPassenger() {
        Random random = new Random();
        int currentFloor = random.nextInt(NUM_FLOORS ) - 1; // Random current floor (-1 to NUM_FLOORS)
        int targetFloor;
        do {
            targetFloor = random.nextInt(NUM_FLOORS) - 1; // Random target floor (-1 to NUM_FLOORS)
        } while (targetFloor == currentFloor); // Ensure target floor is different from current floor

        Passenger passenger = new Passenger(passengerIdCounter.getAndIncrement(), currentFloor, targetFloor);
        allPassengers.add(passenger);

            try {
                assignPassengerToElevator(passenger);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
    }

    private static void assignPassengerToElevator(Passenger passenger) throws InterruptedException {
        int currentFloor = passenger.getCurrentFloor();
        int targetFloor = passenger.getTargetFloor();

            Elevator elevator = selectElevator(currentFloor, targetFloor);
            if (elevator != null) {
                if(elevator.addPassenger(passenger) == 1){
                    Platform.setImplicitExit(false);
                    int finalCurrentFloor = currentFloor;
                    var klasa = elevator.getClass().getSimpleName();
                    Platform.runLater(()->{
                        ElevatorAnimation.ElevatorMovement(finalCurrentFloor,klasa);});
                        sleep(1100);
                }

                currentFloor = elevator.getCurrentFloor();
            } else {
                int transferFloor = selectTransferFloor(currentFloor, targetFloor);
                if (transferFloor != currentFloor) {
                    elevator = selectElevatorForTransfer(currentFloor, transferFloor);
                    if (elevator != null) {
                        passenger.setTargetFloor(transferFloor);
                        elevator.addPassenger(passenger);
                        currentFloor = elevator.getCurrentFloor();
                        passenger.setCurrentFloor(currentFloor);
                        passenger.setTargetFloor(targetFloor); // Reset target floor
                    }
                }
            }

        // When passenger reaches the target floor
        if (currentFloor == targetFloor) {
            allPassengers.remove(passenger);
            if (allPassengers.isEmpty()) {
                running = false;
                System.out.println("All passengers have reached their destinations. Simulation ending...");
            }
        }
    }

    private static Elevator selectElevator(int currentFloor, int targetFloor) {
        for (Elevator elevator : elevators) {
            if (elevator.canServeFloor(currentFloor) && elevator.canServeFloor(targetFloor)) {
                return elevator;
            }
        }
        return null;
    }

    private static Elevator selectElevatorForTransfer(int currentFloor, int transferFloor) {
        for (Elevator elevator : elevators) {
            if (elevator.canServeFloor(currentFloor) && elevator.canServeFloor(transferFloor)) {
                return elevator;
            }
        }
        return null;
    }

    private static int selectTransferFloor(int currentFloor, int targetFloor) {
        if (targetFloor > currentFloor) {
            for (Elevator elevator : elevators) {
                if (elevator.canServeFloor(currentFloor) && elevator.getHighestFloor() > currentFloor) {
                    return elevator.getHighestFloor();
                }
            }
        } else {
            for (Elevator elevator : elevators) {
                if (elevator.canServeFloor(currentFloor) && elevator.getLowestFloor() < currentFloor) {
                    return elevator.getLowestFloor();
                }
            }
        }
        return currentFloor;
    }

    private static void simulate() {
        long startTime = System.currentTimeMillis();
        Thread[] elevatorThreads = new Thread[NUM_ELEVATORS];

        for (int i = 0; i < NUM_ELEVATORS; i++) {
            final Elevator elevator = elevators[i];
            elevatorThreads[i] = new Thread(() -> {
                while (System.currentTimeMillis() - startTime < 100000) { // 10 seconds simulation or until all passengers are delivered
                    synchronized (elevator) {
                        try {
                            elevator.move();
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
            });
            elevatorThreads[i].start();
        }

        for (Thread thread : elevatorThreads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Simulation ended.");
    }
}