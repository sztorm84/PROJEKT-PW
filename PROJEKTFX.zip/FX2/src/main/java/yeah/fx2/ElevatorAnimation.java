package yeah.fx2;

import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.text.Text;
import yeah.fx2.HelloController;

import java.util.Objects;

import static java.lang.Thread.sleep;

public class ElevatorAnimation extends Application {

    public static HelloController controller;


    @Override
    public void start(Stage primaryStage) throws Exception {


        primaryStage.setTitle("Elevator Animation");
        var fxmlloader = new FXMLLoader(getClass().getResource("WINDAFX.fxml"));
        Scene scene = new Scene(fxmlloader.load(), 1600, 800);
        controller = fxmlloader.getController();
        primaryStage.setScene(scene);
        primaryStage.show();

        double kwadratH = (double) 800 /ElevatorSystem.NUM_FLOORS;
        int floorHeight = 800/ElevatorSystem.NUM_FLOORS;

        controller.kwadrat.setHeight(kwadratH);
        controller.kwadrat1.setHeight(kwadratH);
        controller.kwadrat2.setHeight(kwadratH);
        controller.kwadrat.setWidth(kwadratH/1.6);
        controller.kwadrat1.setWidth(kwadratH/1.6);
        controller.kwadrat2.setWidth(kwadratH/1.6);
        //controller.bartek.setFitHeight(kwadratH/3);
        //controller.bartek.setFitWidth(kwadratH/3);
        TranslateTransition transition = new TranslateTransition(Duration.seconds(1), controller.kwadrat);
        transition.setToY(-floorHeight);
        transition.setOnFinished(event -> {
        });
        transition.play();

        TranslateTransition transition1 = new TranslateTransition(Duration.seconds(1), controller.kwadrat1);
        transition1.setToY(-floorHeight);
        transition1.setOnFinished(event -> {
        });
        transition1.play();

        TranslateTransition transition2 = new TranslateTransition(Duration.seconds(1), controller.kwadrat2);
        transition2.setToY(-floorHeight);
        transition2.setOnFinished(event -> {
        });
        transition2.play();

        ustawPietra();
        ustawPasazerow();
        initializeLayout();

    }

    public static void ustawKondygnacje(){
        double kwadratH = (double) 800 /ElevatorSystem.NUM_FLOORS;
        int floorHeight = 800/ElevatorSystem.NUM_FLOORS;

        controller.kwadrat.setHeight(kwadratH);
        controller.kwadrat1.setHeight(kwadratH);
        controller.kwadrat2.setHeight(kwadratH);
        controller.kwadrat.setWidth(kwadratH/1.6);
        controller.kwadrat1.setWidth(kwadratH/1.6);
        controller.kwadrat2.setWidth(kwadratH/1.6);
        //controller.bartek.setFitHeight(kwadratH/3);
        //controller.bartek.setFitWidth(kwadratH/3);
        ustawPietra();
        ustawPasazerow();

        TranslateTransition transition = new TranslateTransition(Duration.seconds(1), controller.kwadrat);
        transition.setToY(-floorHeight);
        transition.setOnFinished(event -> {
        });
        transition.play();

        TranslateTransition transition1 = new TranslateTransition(Duration.seconds(1), controller.kwadrat1);
        transition1.setToY(-floorHeight);
        transition1.setOnFinished(event -> {
        });
        transition1.play();

        TranslateTransition transition2 = new TranslateTransition(Duration.seconds(1), controller.kwadrat2);
        transition2.setToY(-floorHeight);
        transition2.setOnFinished(event -> {
        });
        transition2.play();
    }

    public static void ustawPietra() {

        controller.KOLUMNATEXT.getChildren().clear();
        for (int i = 0; i < ElevatorSystem.NUM_FLOORS; i++) {
            Text text = new Text("Piętro " + (i-1));
            controller.KOLUMNATEXT.getChildren().add(text);
            double translateY = ( -i* (800.0 / ElevatorSystem.NUM_FLOORS));
            text.setTranslateY(translateY);

        }
    }

    public static void ustawPasazerow(){
        double kwadratH = (double) 800 /ElevatorSystem.NUM_FLOORS;
        controller.pasazerowiekolumna.getChildren().clear();
        for (int i = 0; i < ElevatorSystem.NUM_PASSENGERS; i++) {
            Circle circle = new Circle(kwadratH/5);
            circle.setFill(Color.RED);
            controller.pasazerowiekolumna.getChildren().add(circle);
            double translateY = ( -i* (800.0 / ElevatorSystem.NUM_FLOORS));
            circle.setTranslateY(translateY);
        }
    }



    public static void ElevatorMovement(int nextFloor, String klasa) {
        int floorHeight = 800/ElevatorSystem.NUM_FLOORS;
        double targetY = -(nextFloor+1) * floorHeight;

        if(Objects.equals(klasa, "W1")) {
            TranslateTransition transition = new TranslateTransition(Duration.seconds(1), controller.kwadrat);
            transition.setToY(targetY);
            transition.setOnFinished(event -> {
            });
            transition.play();
        }
        if(Objects.equals(klasa, "W2")) {
            TranslateTransition transition = new TranslateTransition(Duration.seconds(1), controller.kwadrat1);
            transition.setToY(targetY);
            transition.setOnFinished(event -> {
            });
            transition.play();
        }
        if(Objects.equals(klasa, "W3")) {
            TranslateTransition transition = new TranslateTransition(Duration.seconds(1), controller.kwadrat2);
            transition.setToY(targetY);
            transition.setOnFinished(event -> {
            });
            transition.play();
        }
    }

    public static void initializeLayout() throws InterruptedException
    {
            //sleep(100);
            //rower.controller.sep.setPrefHeight(200+i);
            //TranslateTransition transition = new TranslateTransition(Duration.seconds(0.5));
            //transition.setByX(-140);
            //transition.setOnFinished(event -> {});
            //transition.play();
           // controller.TEXT.setText("");
    }

    public static void main(String[] args) {
        launch(args);
    }
}
