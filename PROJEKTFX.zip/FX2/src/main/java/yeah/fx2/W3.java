package yeah.fx2;

class W3 extends Elevator {
    public W3(int maxCapacity) {
        super(maxCapacity);
    }

    @Override
    public boolean canServeFloor(int floor) {
        return floor <= 0;
    }

    @Override
    public int getHighestFloor() {
        return 0;
    }

    @Override
    public int getLowestFloor() {
        return -1;
    }
}