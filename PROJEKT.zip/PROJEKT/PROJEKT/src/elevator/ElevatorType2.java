package elevator;

class W2 extends Elevator {
    public W2(int maxCapacity) {
        super(maxCapacity);
    }

    @Override
    public boolean canServeFloor(int floor) {
        return floor == 0 || floor <= ElevatorSystem.NUM_FLOORS && floor >= (ElevatorSystem.NUM_FLOORS/2)+1;
    }

    @Override
    public int getHighestFloor() {
        return ElevatorSystem.NUM_FLOORS;
    }

    @Override
    public int getLowestFloor() {
        return 0;
    }
}