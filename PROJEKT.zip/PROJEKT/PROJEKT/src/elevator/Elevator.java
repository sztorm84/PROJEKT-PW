package elevator;

import java.util.concurrent.Semaphore;

abstract class Elevator {
    protected int currentFloor;
    protected int maxCapacity;
    protected Passenger[] passengers;
    protected int passengerCount;
    protected int[] targetFloors;
    protected int targetFloorCount;
    protected final Object lock;
    protected final Semaphore semaphore;
    private volatile boolean running = true;

    public Elevator(int maxCapacity) {
        this.currentFloor = 0;
        this.maxCapacity = maxCapacity;
        this.passengers = new Passenger[maxCapacity];
        this.passengerCount = 0;
        this.targetFloors = new int[maxCapacity];
        this.targetFloorCount = 0;
        this.lock = new Object();
        this.semaphore = new Semaphore(maxCapacity);
    }

    public abstract boolean canServeFloor(int floor);
    public abstract int getHighestFloor();
    public abstract int getLowestFloor();

    public void move() {
        synchronized (lock) {
            if (running && targetFloorCount > 0) {
                int nextFloor = targetFloors[0];
                if (!canServeFloor(nextFloor)) {
                    System.out.println(getClass().getSimpleName() + " cannot move to floor " + nextFloor);
                    return;
                }
                for (int i = 0; i < targetFloorCount - 1; i++) {
                    targetFloors[i] = targetFloors[i + 1];
                }
                targetFloorCount--;
                currentFloor = nextFloor;
                System.out.println(getClass().getSimpleName() + " moved to floor " + currentFloor);
                removePassengers();
                lock.notifyAll(); // Notify waiting passengers
            }
        }
    }

    public void addPassenger(Passenger passenger) throws InterruptedException {
        semaphore.acquire();
        synchronized (lock) {
            if (passengerCount < maxCapacity) {
                passengers[passengerCount++] = passenger;
                boolean found = false;
                for (int i = 0; i < targetFloorCount; i++) {
                    if (targetFloors[i] == passenger.getTargetFloor()) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    targetFloors[targetFloorCount++] = passenger.getTargetFloor();
                }
                System.out.println("Passenger (" + passenger.getId() + ") " + getClass().getSimpleName() + " " + passenger.getCurrentFloor() + "-->" + passenger.getTargetFloor());
            }
        }
    }

    private void removePassengers() {
        synchronized (lock) {
            int i = 0;
            while (i < passengerCount) {
                if (passengers[i].getTargetFloor() == currentFloor) {
                    System.out.println("Passenger (" + passengers[i].getId() + ") exited " + getClass().getSimpleName() + " at floor " + currentFloor);
                    for (int j = i; j < passengerCount - 1; j++) {
                        passengers[j] = passengers[j + 1];
                    }
                    passengers[--passengerCount] = null;
                    semaphore.release();
                } else {
                    i++;
                }
            }
        }
    }

    public int getCurrentFloor() {
        return currentFloor;
    }

    public void stopElevator() {
        running = false;
    }
}