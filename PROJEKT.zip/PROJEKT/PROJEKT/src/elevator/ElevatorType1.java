package elevator;

class W1 extends Elevator {
    public W1(int maxCapacity) {
        super(maxCapacity);
    }

    @Override
    public boolean canServeFloor(int floor) {
        return floor >= 0 && floor <= ElevatorSystem.NUM_FLOORS / 2;
    }

    @Override
    public int getHighestFloor() {
        return ElevatorSystem.NUM_FLOORS / 2;
    }

    @Override
    public int getLowestFloor() {
        return 0;
    }
}